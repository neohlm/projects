/**
@author Neo Hlumbene
*/

public class QueueAsMyLinkedList<E> 
{
    private MyLinkedList<E> theQueue;

    public QueueAsMyLinkedList() 
	{
        theQueue = new MyLinkedList<>();
    }

    public void enqueue(E element) 
	{
        theQueue.append(element);
    }

    public E dequeue() 
	{
        return theQueue.removeFirst();
    }

    public int size() 
	{
        return theQueue.size();
    }

    public boolean isEmpty() 
	{
        return theQueue.size() == 0;
    }

    public String toString() 
	{
        return theQueue.toString();
    }
}