/**
@author Neo Hlumbene
*/

public class StackAsMyLinkedList<E> 
{
    private MyLinkedList<E> theStack;

    public StackAsMyLinkedList() 
	{
        theStack = new MyLinkedList<>();
    }

    public void push(E element) 
	{
        theStack.prepend(element);
    }

    public E pop() 
	{
        return theStack.removeFirst();
    }

    public int size() 
	{
        return theStack.size();
    }

    public boolean isEmpty() 
	{
        return theStack.size() == 0;
    }

    public String toString() 
	{
        return theStack.toString();
    }
}