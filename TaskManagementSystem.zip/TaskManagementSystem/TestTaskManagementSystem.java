/**
@author Neo Hlumbene
*/

public class TestTaskManagementSystem 
{
    public static void main(String[] args) 
	{
        TaskManagementSystem tasks = new TaskManagementSystem();

        tasks.addTask("Task 1"); //adding items to the queue
        tasks.addTask("Task 2");
        tasks.addTask("Task 3");

        tasks.displayStatus();

        tasks.processNextTask();
        tasks.displayStatus();

        tasks.undoLastTask();
        tasks.displayStatus();
    }
}