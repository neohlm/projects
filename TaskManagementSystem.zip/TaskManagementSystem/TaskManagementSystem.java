/**
@author Neo Hlumbene
*/

public class TaskManagementSystem 
{
    private QueueAsMyLinkedList<String> queueTask;
    private StackAsMyLinkedList<String> unstack;

    public TaskManagementSystem() 
	{
        queueTask = new QueueAsMyLinkedList<>();
        unstack = new StackAsMyLinkedList<>();
    }

    public void addTask(String task) 
	{
        queueTask.enqueue(task);
    }

    public void processNextTask() 
	{
        if (!queueTask.isEmpty()) 
		{
            String task = queueTask.dequeue();
            unstack.push(task);
        }
    }

    public void undoLastTask() 
	{
        if (!unstack.isEmpty()) 
		{
            String task = unstack.pop();
            queueTask.enqueue(task);
        }
    }

    public void displayStatus() 
	{
        System.out.println("Task Queue: " + queueTask.toString());
        System.out.println("Undo Stack: " + unstack.toString());
    }
}